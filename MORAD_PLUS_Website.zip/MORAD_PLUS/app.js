const searchInput = document.getElementById("searchInput");
const cards = [...document.querySelectorAll(".app-card")];
const filters = [...document.querySelectorAll(".filter")];
const emptyState = document.getElementById("emptyState");
let activeFilter = "all";

function updateCards() {
  const term = searchInput.value.trim().toLowerCase();
  let visible = 0;
  cards.forEach(card => {
    const matchesFilter = activeFilter === "all" || card.dataset.category === activeFilter;
    const matchesSearch = (card.dataset.name + " " + card.innerText).toLowerCase().includes(term);
    const show = matchesFilter && matchesSearch;
    card.hidden = !show;
    if (show) visible++;
  });
  emptyState.hidden = visible !== 0;
}
filters.forEach(button => button.addEventListener("click", () => {
  filters.forEach(item => item.classList.remove("active"));
  button.classList.add("active");
  activeFilter = button.dataset.filter;
  updateCards();
}));
searchInput.addEventListener("input", updateCards);

document.getElementById("menuBtn").addEventListener("click", () => {
  document.querySelector(".nav").classList.toggle("open");
});
document.querySelectorAll(".nav a").forEach(link => link.addEventListener("click", () => {
  document.querySelector(".nav").classList.remove("open");
}));
